<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <title>📬 최근 메시지</title>
  <link href="https://fonts.googleapis.com/css2?family=Noto+Color+Emoji" rel="stylesheet">
  <style>
    body {
      font-family: 'Noto Color Emoji', 'Segoe UI Emoji', sans-serif;
    }
  </style>
</head>
<body>
  <h1>📬 최근 메시지</h1>
  <ul>
    <% messages.forEach(msg => { %>
      <li><%= msg.content %> - <%= msg.created_at %></li>
    <% }) %>
  </ul>
</body>
</html>